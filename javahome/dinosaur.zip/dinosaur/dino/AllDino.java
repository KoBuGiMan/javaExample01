package dino;

import java.util.Arrays;


public class AllDino {
	public static void main(String[] args) {
		ControlToolDino con = new ControlToolDino();

		con.earthSet();
		con.earthGet();
		con.earthSet();
		con.earthGet();

	}

}
