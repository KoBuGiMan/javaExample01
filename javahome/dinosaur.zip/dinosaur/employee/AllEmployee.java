package employee;

public class AllEmployee {
	
	public static void main(String[] args) {
		
	}
	

}
